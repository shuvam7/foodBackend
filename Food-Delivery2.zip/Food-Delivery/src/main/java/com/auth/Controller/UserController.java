package com.auth.Controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.MultipartConfig;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.auth.Service.UserService;

import com.auth.model.User;
import com.google.gson.Gson;

@CrossOrigin
@RestController
public class UserController {

	@Autowired
	UserService userService;

	@RequestMapping(value = { "/book" }, method = RequestMethod.GET)
	public String book(Model model) {
		return "book";
	}

	@RequestMapping(value = { "/add_item" }, method = RequestMethod.GET)
	public String add(Model model) {
		return "add";
	}
	@PostMapping("/user/login")
	public ResponseEntity<Map<String, String>> login(@RequestBody User user) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(user.getEmailId());
		System.out.println(userService.checkUser(user));
		if (userService.checkUser(user)) {
			List<User> fetchUser=userService.getUserId(user);
			String id=Integer.toString(fetchUser.get(0).getId());
			map.put("message", "User logged in sccessfully");
			map.put("id", id);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			
			map.put("message", "Username/Password is wrong");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}
	
	}
	@PostMapping("/user/signup")
	public ResponseEntity<Map<String, String>> registerUser(@RequestBody User user) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(user.getEmailId());
		if (userService.saveUser(user)) {

			map.put("message", "User registered successfully");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			System.out.println(userService.saveUser(user));
			map.put("message", "User already exists with this ID");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}

	}

	
	

	

}
