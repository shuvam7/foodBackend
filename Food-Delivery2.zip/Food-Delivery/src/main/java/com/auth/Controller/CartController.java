package com.auth.Controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.auth.Service.CartService;
import com.auth.model.Cart;
import com.auth.model.User;
import com.google.gson.Gson;

@CrossOrigin
@RestController
public class CartController {
	@Autowired
	CartService cartService;
	@PostMapping("/cart/list")
	public void cartList(HttpServletResponse res,@RequestBody User user) throws IOException {
		
		
		List<Cart> result=cartService.fetchCart(user);

			String json = new Gson().toJson(result);
			res.setContentType("application/json");
			res.getWriter().write(json);
	}
	@PostMapping("/cart/delete")
	public ResponseEntity<Map<String, String>> cartDelete(@RequestBody Cart cart) {
		Map<String, String> map = new HashMap<String, String>();
		if (cartService.removeItem(cart)) {

			map.put("message", "Item removed");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			map.put("message", "Item cannot be removed");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}

	}
	@PostMapping("/cart/update")
	public void updateCart(HttpServletResponse res,@RequestBody Cart cart) throws IOException {
		List<Cart> result =null;
		if(cartService.updateCart(cart)){
		result = cartService.fetchCart(cart.getUser());
		}
			String json = new Gson().toJson(result);
			res.setContentType("application/json");
			res.getWriter().write(json);
	}
	@PostMapping("/cart/add")
	public ResponseEntity<Map<String, String>> cartAdd(@RequestBody Cart cart) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(cart.getFood().getName());
		if (cartService.saveCart(cart)) {

			map.put("message", "Added to cart");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			
			map.put("message", "Cannot be added to cart");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}	
	}
}
