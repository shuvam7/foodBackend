package com.auth.Service;
import java.util.List;
import com.auth.model.Food;


public interface FoodService{
public List<Food> getfoodList();
public List<Food> findFoodById(int id);
public String placeOrder(int id,int quantity);
public String uploadFood(Food food);


}
