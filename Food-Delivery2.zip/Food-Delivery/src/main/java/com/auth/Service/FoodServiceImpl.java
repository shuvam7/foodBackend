package com.auth.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.el.PropertyNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.auth.Repository.CartRepository;
import com.auth.Repository.FoodRepository;
import com.auth.model.Cart;
import com.auth.model.Food;
import com.auth.model.User;

@Service
public class FoodServiceImpl implements FoodService {
	@Autowired
	FoodRepository foodRepository;
	@Autowired
	CartRepository cartRepository;
	@Transactional
	@Override
	public List<Food> getfoodList() {
		// TODO Auto-generated method stub
		List<Food> list = (List<Food>) foodRepository.findAll();

		return list;

	}

	@Transactional
	@Override
	public List<Food> findFoodById(int id) {
		ArrayList<Food> res = new ArrayList<>();
		if (foodRepository.existsById(id)) {
			Optional<Food> food = foodRepository.findById(id);

			if (food.isPresent())
				res.add(food.get());

		}
		return res;

	}

	@Transactional
	@Override
	public String placeOrder(int id, int quantity) {
		String status = "error";
		if (foodRepository.existsById(id)) {
			List<Food> food = foodRepository.validateNoOfOrder(quantity, id);
			if (food.size() > 0) {

				for (Food fo : food) {
					quantity = fo.getQuantity() - quantity;
				}
				foodRepository.updateByQuantity(quantity, id);
					status = "true";
			}
		}
		return status;
	}
	@Transactional
	@Override
	public String uploadFood(Food food) {
		String status = "error";
		Food save=foodRepository.save(food);
		if(save!=null)
			status="success";
		return status;
	}

	@Override
	public boolean saveCart(Cart cart) {
		// TODO Auto-generated method stub
		Cart cartRes=null;
		cartRes=cartRepository.save(cart);
		if(cartRes!=null)
		{
		return true;
		}
		return false;
	}

	@Override
	public List<Cart> fetchCart(User user) {
		// TODO Auto-generated method stub
		List<Cart> list = (List<Cart>) cartRepository.findAllByUserId(user.getId());

		return list;
	}

	@Override
	public boolean removeItem(Cart cart) {
		// TODO Auto-generated method stub
		cartRepository.delete(cart);;
		return true;
	}
	@Transactional
	@Override
	public boolean updateCart(Cart cart) {
		// TODO Auto-generated method stub
		int quantity=cart.getNoOfQty();
		int id=cart.getId();
		System.out.println(quantity);
		System.out.println(id);
		cartRepository.updateByQuantityCart(quantity, id);;
		return true;
	}

}
