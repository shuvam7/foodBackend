package com.auth.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.auth.Repository.UserRepository;
import com.auth.model.User;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserRepository userRepository;
	@Override
	public boolean saveUser(User user) {
		// TODO Auto-generated method stub
		String emailId=user.getEmailId();
		System.out.println(userRepository.findByEmail(emailId));
		if(userRepository.findByEmail(emailId).size()==0)
		{
			User userSaved=null;
			 userSaved=userRepository.save(user);
				if(userSaved==null)
				{
					System.out.println(userSaved.getUsername());
					return false;
				}
				else
				{
					return true;
				}
		}
		else
		{
			return false;
		}
		
		
	}
	@Override
	public boolean checkUser(User user) {
		// TODO Auto-generated method stub
		if(userRepository.findByUsernamePassword(user.getEmailId(),user.getPassword()).size()>=1 )
		{
			return true;
		}
		else
		{
			System.out.println(userRepository.findByUsernamePassword(user.getEmailId(),user.getPassword()).size());
			return false;
		}
	}
	@Override
	public List<User> getUserId(User user) {
		// TODO Auto-generated method stub
		String emailId=user.getEmailId();
			return userRepository.findByEmail(emailId);
		
	}

	
	
}
