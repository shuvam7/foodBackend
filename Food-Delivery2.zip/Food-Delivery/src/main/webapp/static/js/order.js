	
 function uploadItem(id) {	
		
	var formData = new FormData();
	formData.append('file', $('#file')[0].files[0]);
    formData.append('user', new Blob([JSON.stringify({
        "name": document.getElementById("name").value,
        "price": document.getElementById("price").value,
        "quantity": document.getElementById("quantity").value
    })], {
            type: "application/json"
        }));
		
			$.ajax({
				url : 'upload',
				type : 'POST',
				data : formData,
				processData : false,
				contentType : false, 
				success : function(data) {
					console.log(data);
					
				}
			});
		};