package com.auth.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.auth.model.Cart;
import com.auth.model.Food;

@Repository
public interface CartRepository extends CrudRepository<Cart,Integer>{
	  @Query("from Cart f where f.user.id=:userId")
	   List<Cart> findAllByUserId(@Param("userId") int userId);
	   
	   @Modifying
	   @Query("update Food f set f.quantity =:quantity where f.id =:id")
	   void updateByQuantityFood(@Param("quantity") int quantity,@Param("id") int id);
	  
	   @Modifying
	   @Query("update Cart f set f.noOfQty =:quantity where f.id =:id")
	   void updateByQuantityCart(@Param("quantity") int quantity,@Param("id") int id);
}
