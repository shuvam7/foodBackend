package com.auth.Controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.auth.Service.FoodService;
import com.auth.model.Food;
import com.google.gson.Gson;
@CrossOrigin
@MultipartConfig
@RestController
@RequestMapping(path="/api/v1/food")
public class FoodController {
	@Autowired
	FoodService foodService;
	@GetMapping("/list")
	public void fetchFood(HttpServletRequest req, HttpServletResponse res) throws IOException {
		List<Food> result = foodService.getfoodList();
		String json = new Gson().toJson(result);
		res.setContentType("application/json");
		res.getWriter().write(json);
	}
}
