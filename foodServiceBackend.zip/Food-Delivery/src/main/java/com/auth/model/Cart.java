package com.auth.model;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "cart")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int id;
	private int noOfQty;
	@ManyToOne
	private Food food;
	 @ManyToOne
	private User user;
	public int getNoOfQty() {
		return noOfQty;
	}
	public void setNoOfQty(int noOfQty) {
		this.noOfQty = noOfQty;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public Food getFood() {
		return food;
	}
	public void setFood(Food food) {
		this.food = food;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
}
