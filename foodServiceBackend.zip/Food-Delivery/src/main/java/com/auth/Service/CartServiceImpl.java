package com.auth.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.auth.Repository.CartRepository;
import com.auth.Repository.FoodRepository;
import com.auth.model.Cart;
import com.auth.model.User;
@Service
public class CartServiceImpl implements CartService{
	@Autowired
	CartRepository cartRepository;
	@Autowired
	FoodRepository foodRepository;
	 @Transactional
	@Override
	public boolean saveCart(Cart cart) {
		// TODO Auto-generated method stub
		Cart cartRes=null;
		cartRes=cartRepository.save(cart);
		if(cartRes!=null)
		{
		return true;
		}
		return false;
	}
   @Transactional
	@Override
	public List<Cart> fetchCart(User user) {
		// TODO Auto-generated method stub
		List<Cart> list = (List<Cart>) cartRepository.findAllByUserId(user.getId());
		return list;
	}
   @Transactional
	@Override
	public boolean removeItem(Cart cart) {
		// TODO Auto-generated method stub
		cartRepository.delete(cart);;
		return true;
	}
	@Transactional
	@Override
	public boolean updateCart(Cart cart) {
		// TODO Auto-generated method stub
		int quantity=cart.getNoOfQty();
		int id=cart.getId();
		cartRepository.updateByQuantityCart(quantity, id);
		return true;
	}
	@Transactional
	@Override
	public boolean order(User user) {
		// TODO Auto-generated method stub
		List<Cart> list = (List<Cart>) cartRepository.findAllByUserId(user.getId());
         for(Cart cart :list)
         {
        	 if(cart.getFood().getQuantity()>cart.getNoOfQty())
        	 {
        		 int quantity=cart.getFood().getQuantity()-cart.getNoOfQty();
        		 foodRepository.updateByQuantity(quantity, cart.getFood().getId());
        		 cartRepository.delete(cart);
        	 }
         }
		return true;
	}
}
