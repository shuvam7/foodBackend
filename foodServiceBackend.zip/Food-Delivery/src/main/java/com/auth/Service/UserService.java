package com.auth.Service;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.auth.model.User;

public interface UserService {
	public boolean saveUser(User user);
	public boolean checkUser(User user);
	public List<User> getUserId(User user);
}
