var clicks = 0;
		function addonclick(price) {
			console.log(clicks);
			clicks++;
			if(clicks>0)
				$('#sub').attr("disabled", false);
			var amount=clicks*price;
			$("#h4").html(amount);
			
			$('#usr').val(clicks);
		};
		function subonclick(price) {
			console.log(clicks);
			if(clicks>0)
			clicks--;
		 if(clicks==0)
				$('#sub').attr("disabled", true);
			var amount=clicks*price;
			$("#h4").html(amount);
			
			$('#usr').val(clicks);
		};
		function orderItem(id) {
			$.ajax({
				url : "orderfood",
				type : "POST",
				data:{id:id,
					quantity:clicks},
				success : function(data) {
					console.log(data);

				},
				error : function(data) {
					alert("error");
				}
			});
		};
		

		$(document).ready(
				function() {
						var html = '';
						$.ajax({
							url : "fetch_food",
							type : "POST",
							success : function(data) {
								console.log(data);
								
								 for (var i = 0; i < data.length; i++) {
									
									html +='<div class="col-md-4" style="margin-top:50px"><div class="card" ><img class="card-img-top" src="'
										+data[i].path+'" alt="Card image cap"><div class="card-body"><h5 class="card-title">'
										+data[i].name+'</h5><p class="card-text">A world-renowned Indian dish, biryani takes time and practice to make but is worth every bit of the effort.</p></div><div class="card-body"><span class="card-link">Price</span> <span class="card-link">Rs '
										+data[i].price+'</span><a href="/orderfood/'
										+ data[i].id + '" class="card-link">Order</a></div></div></div>';
										
										
										
				
								}
								setTimeout(function() {
									$('#list').append(html);
								}, 50); 

							},
							error : function() {
								alert("error");
							}
						}); 
					}) ;		
		
		


		


