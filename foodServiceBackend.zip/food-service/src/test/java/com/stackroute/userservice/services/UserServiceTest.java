package com.stackroute.userservice.services;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.stackroute.userservice.exception.UserAlreadyExistsException;
import com.stackroute.userservice.exception.UserNotFoundException;
import com.stackroute.userservice.model.User;
import com.stackroute.userservice.repositories.UserRepository;


public class UserServiceTest {
	@Mock
	UserRepository repository;
	
	private User user;
	
	@InjectMocks
	UserServiceImpl service;
	
   @Mock
	BCryptPasswordEncoder encryptor;
	
	@Before
	public void setup()
	{
		MockitoAnnotations.initMocks(this);
		user = new User("Shuvam", "ShuvamRoy@gmail.com", "7044314822", "12112312322");
		
	}
	
	@Test
	public void testSaveUser() throws UserAlreadyExistsException
	{
		
		when(repository.findByEmailId(user.getEmailId())).thenReturn(null);
		when(repository.save(user)).thenReturn(user);
		when(encryptor.encode(user.getPassword())).thenCallRealMethod();
		boolean flag=service.saveUser(user);
		assertEquals("can Register user",true,flag);
		verify(repository, times(1)).save(user);
		verify(repository, times(1)).findByEmailId(user.getEmailId());
		verify(encryptor,times(1)).encode(Mockito.anyString());
	}
	
	@Test(expected=UserAlreadyExistsException.class)
	public void testSaveUserFailure() throws UserAlreadyExistsException 
	{
		when(repository.findByEmailId(user.getEmailId())).thenReturn(user);
		when(repository.save(user)).thenReturn(user);
		
		boolean flag = service.saveUser(user);
		assertTrue("saving user failed", flag);
		verify(repository, times(1)).findByEmailId(user.getEmailId());
		
	}
	
	@Test
	public void testValidateSuccess() throws UserNotFoundException
	{
		when(repository.findByEmailId(user.getEmailId())).thenReturn(user);
		when(encryptor.matches("ShuvamRoy@gmail.com",user.getPassword())).thenReturn(true);
		User userResult = service.findByIdAndPassword(user.getEmailId(), user.getPassword());
		assertNotNull(userResult);
		assertEquals(user.getId(), userResult.getId());
		verify(repository, times(1)).findByEmailId(user.getEmailId());
		verify(encryptor,times(1)).matches(Mockito.anyString(),Mockito.anyString());
	}

}

