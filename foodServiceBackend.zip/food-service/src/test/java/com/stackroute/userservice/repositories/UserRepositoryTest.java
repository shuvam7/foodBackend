package com.stackroute.userservice.repositories;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.userservice.model.User;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class UserRepositoryTest {
	@Autowired
	private transient UserRepository userRepository;

	private User user;


	@Test
	public void testRegisterUserSuccess() {
		user = new User("Shuvam", "ShuvamRoy@gmail.com", "7044314822", "12112312322");
		userRepository.save(user);
		User userToFind = userRepository.findByEmailId(user.getEmailId());
		assertThat(userToFind.equals(user));
	}


}
