package com.stackroute.userservice.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.userservice.model.User;







/**
 * @author 729707
 *
 */
public interface UserRepository extends JpaRepository<User, String> {

	/*@Query("Select user from User user where user.userId = (?1) and user.password = (?2)")
	User validate(String userId, String password);*/
	User findByEmailId(String emailId);
}
