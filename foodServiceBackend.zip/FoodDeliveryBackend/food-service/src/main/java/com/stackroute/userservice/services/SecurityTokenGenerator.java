package com.stackroute.userservice.services;

import java.util.Map;

import com.stackroute.userservice.model.User;



/**
 * @author 729707
 *
 */
public interface SecurityTokenGenerator {

	Map<String, String> generateToken(User user);
}
