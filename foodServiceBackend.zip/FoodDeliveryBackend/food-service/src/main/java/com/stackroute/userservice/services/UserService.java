package com.stackroute.userservice.services;

import com.stackroute.userservice.exception.UserAlreadyExistsException;
import com.stackroute.userservice.exception.UserNotFoundException;
import com.stackroute.userservice.model.User;

/**
 * @author 729707
 *
 */
public interface UserService {

	boolean saveUser(User user) throws UserAlreadyExistsException;

	User findByIdAndPassword(String userId, String password) throws UserNotFoundException;
}
