package com.stackroute.userservice.exception;

/**
 * @author 729707
 *
 */
public class UserAlreadyExistsException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
	 * @param arg0
	 */

	public UserAlreadyExistsException(String message) {
		super(message);
	}

}
