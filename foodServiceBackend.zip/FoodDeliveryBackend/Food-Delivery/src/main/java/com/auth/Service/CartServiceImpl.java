package com.auth.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.auth.Repository.CartRepository;
import com.auth.model.Cart;
import com.auth.model.User;
@Service
public class CartServiceImpl implements CartService{
	@Autowired
	CartRepository cartRepository;
	@Override
	public boolean saveCart(Cart cart) {
		// TODO Auto-generated method stub
		Cart cartRes=null;
		cartRes=cartRepository.save(cart);
		if(cartRes!=null)
		{
		return true;
		}
		return false;
	}

	@Override
	public List<Cart> fetchCart(User user) {
		// TODO Auto-generated method stub
		List<Cart> list = (List<Cart>) cartRepository.findAllByUserId(user.getId());

		return list;
	}

	@Override
	public boolean removeItem(Cart cart) {
		// TODO Auto-generated method stub
		cartRepository.delete(cart);;
		return true;
	}
	@Transactional
	@Override
	public boolean updateCart(Cart cart) {
		// TODO Auto-generated method stub
		int quantity=cart.getNoOfQty();
		int id=cart.getId();
		System.out.println(quantity);
		System.out.println(id);
		cartRepository.updateByQuantityCart(quantity, id);;
		return true;
	}
}
