package com.auth.Service;

import java.util.List;

import com.auth.model.Cart;
import com.auth.model.User;

public interface CartService {
	public boolean saveCart(Cart cart);
	public List<Cart> fetchCart(User user);
	public boolean removeItem(Cart cart);
	public boolean updateCart(Cart cart);
}
