package com.auth.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.auth.model.User;
@Repository
public interface UserRepository extends CrudRepository<User, Integer>{
	 @Query("from User f where f.emailId=:emailId ")
	   List<User> findByEmail(@Param("emailId") String emailId);
	 @Query("from User f where f.emailId=:emailId  and f.password>=:password")
	   List<User> findByUsernamePassword(@Param("emailId") String emailId,@Param("password") String password);
}
