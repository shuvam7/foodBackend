package com.auth.Controller;

import java.io.BufferedOutputStream;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.auth.Service.FoodService;
import com.auth.Service.UserService;
import com.auth.model.Cart;
import com.auth.model.Food;
import com.auth.model.User;
import com.google.gson.Gson;

@CrossOrigin
@MultipartConfig
@RestController
public class UserController {

	@Autowired
	FoodService roomService;

	@Autowired
	UserService userService;

	@RequestMapping(value = { "/book" }, method = RequestMethod.GET)
	public String book(Model model) {
		return "book";
	}

	@RequestMapping(value = { "/add_item" }, method = RequestMethod.GET)
	public String add(Model model) {
		return "add";
	}
	@PostMapping("/user/login")
	public ResponseEntity<Map<String, String>> login(@RequestBody User user) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(user.getEmailId());
		System.out.println(userService.checkUser(user));
		if (userService.checkUser(user)) {
			List<User> fetchUser=userService.getUserId(user);
			String id=Integer.toString(fetchUser.get(0).getId());
			map.put("message", "User logged in sccessfully");
			map.put("id", id);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			
			map.put("message", "Username/Password is wrong");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}
	
	}
	@PostMapping("/user/signup")
	public ResponseEntity<Map<String, String>> registerUser(@RequestBody User user) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(user.getEmailId());
		if (userService.saveUser(user)) {

			map.put("message", "User registered successfully");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			System.out.println(userService.saveUser(user));
			map.put("message", "User already exists with this ID");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}

	}

	@PostMapping("/cart/add")
	public ResponseEntity<Map<String, String>> cartAdd(@RequestBody Cart cart) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(cart.getFood().getName());
		if (roomService.saveCart(cart)) {

			map.put("message", "Added to cart");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			
			map.put("message", "Cannot be added to cart");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}	
	}
	@RequestMapping(value = { "/upload" }, method = RequestMethod.POST)
	public void upload(HttpServletRequest req, HttpServletResponse res, @RequestPart("user") Food food,
			@RequestParam MultipartFile file, Model model) throws IOException {
		String status = "";
		if (!file.isEmpty()) {
			byte[] bytes = file.getBytes();
			String filename = file.getOriginalFilename();
			food.setFilename(filename);
			String uploadsDir = "/uploads/";
			String realPathtoUploads = req.getServletContext().getRealPath(uploadsDir);
			if (!new File(realPathtoUploads).exists()) {
				new File(realPathtoUploads).mkdir();
			}
			String filePath = realPathtoUploads + filename;
			File dest = new File(filePath);
			file.transferTo(dest);
			food.setPath("http://localhost:8888/uploads/" + filename);
			status = roomService.uploadFood(food);
		}
		String json = new Gson().toJson(status);
		res.setContentType("application/json");
		res.getWriter().write(json);
	}

	@RequestMapping(value = { "/food/list" }, method = RequestMethod.GET)
	public void fetchFood(HttpServletRequest req, HttpServletResponse res) throws IOException {
		List<Food> result = roomService.getfoodList();
		String json = new Gson().toJson(result);
		res.setContentType("application/json");
		res.getWriter().write(json);
	}
	@PostMapping("/cart/list")
	public void cartList(HttpServletResponse res,@RequestBody User user) throws IOException {
		
		
		List<Cart> result=roomService.fetchCart(user);

			String json = new Gson().toJson(result);
			res.setContentType("application/json");
			res.getWriter().write(json);
	}
	@PostMapping("/cart/delete")
	public ResponseEntity<Map<String, String>> cartDelete(@RequestBody Cart cart) {
		Map<String, String> map = new HashMap<String, String>();
		System.out.println(cart.getId());
		if (roomService.removeItem(cart)) {

			map.put("message", "Item removed");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CREATED);
		} else {
			map.put("message", "Item cannot be removed");
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.CONFLICT);
		}

	}
	@PostMapping("/cart/update")
	public void updateCart(HttpServletResponse res,@RequestBody Cart cart) throws IOException {
		List<Cart> result =null;
		
		System.out.println(cart.getId());
		if(roomService.updateCart(cart)){
		result = roomService.fetchCart(cart.getUser());
		}
			String json = new Gson().toJson(result);
			res.setContentType("application/json");
			res.getWriter().write(json);
	}
	

	@RequestMapping(value = "/orderfood/{id}", method = RequestMethod.GET)
	public String order(@PathVariable("id") int id, HttpServletRequest request, Model model) {
		List<Food> result = (java.util.List<Food>) roomService.findFoodById(id);
		for (Food ro : result)
			System.out.println(ro.getId());
		model.addAttribute("result", result);
		return "order";
	}

	@RequestMapping(value = "/orderfood", method = RequestMethod.POST)
	public @ResponseBody List<String> placeorder(HttpServletRequest request, Model model) {
		int id = Integer.parseInt(request.getParameter("id"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		String result = roomService.placeOrder(id, quantity);
		List<String> res = new ArrayList<>();
		res.add(result);
		return res;
	}

}
