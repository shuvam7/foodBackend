package com.auth.Service;

import java.text.ParseException;
import java.util.List;

import com.auth.model.Cart;
import com.auth.model.Food;
import com.auth.model.User;


public interface FoodService{
public List<Food> getfoodList();
public List<Food> findFoodById(int id);
public String placeOrder(int id,int quantity);
public String uploadFood(Food food);
public boolean saveCart(Cart cart);
public List<Cart> fetchCart(User user);
public boolean removeItem(Cart cart);
public boolean updateCart(Cart cart);

}
